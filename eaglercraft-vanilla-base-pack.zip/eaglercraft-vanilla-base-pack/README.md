# Eaglercraft Vanilla Base

This pack intentionally contains no Minecraft texture files. It does not override the client’s built-in textures, so the Eaglercraft default appearance remains unchanged.

Use this when you want the closest possible vanilla appearance without redistributing Mojang texture assets.
