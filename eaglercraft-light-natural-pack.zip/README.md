# Natural Light 32x32

Detailed original 32×32 pixel-art overrides for Eaglercraft: animated water, foliage, grass and fern; brighter sun and moon; soft clouds; and warm light textures.

Import the ZIP using the client’s **Open file / ファイルを開く** control.

This remains a resource pack, not a shader or MOD: texture animation is used for water and foliage. It does not add real-time shadows, physically based lighting, or geometry-based plant sway.
