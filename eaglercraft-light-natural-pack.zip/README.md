# Natural Light — lightweight Eaglercraft texture pack

Original 16×16 pixel-art overrides for water, foliage, plants, sky discs, clouds, and warm light. Animated water, grass, fern, and leaves are provided as multi-frame textures.

## Import

Use the client’s **Open file / ファイルを開く** control and select `eaglercraft-light-natural-pack.zip`. If the client accepts the pack, reload the world or restart the client.

## Limits

This is a resource pack, not a shader or MOD. It cannot create real-time shadow maps, physically correct lighting, or geometry-based plant sway. Animation is texture-frame animation only. The pack contains original artwork and does not copy vanilla Minecraft textures.
